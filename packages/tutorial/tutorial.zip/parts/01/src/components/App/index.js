import React from 'react'

export default function App (props) {
  return (
    <div className='o-container o-container--medium'>
      <h1>Welcome to the tutorial!</h1>
    </div>
  )
}
