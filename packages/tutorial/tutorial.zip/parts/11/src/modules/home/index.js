import openHome from './chains/openHome'

export default {
  signals: {
    routed: openHome
  }
}
