import {state, set} from 'cerebral/operators'

export default [
  set(state`app.activeTab`, 'home')
]
