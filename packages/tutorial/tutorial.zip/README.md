# cerebral-tutorial
# !!! This tutorial is a WIP !!!
### Temporary Contribution Guidelines
 
**Some considerations if you would like to contribute:**

- Please put your beginners-hat on
- It would be cool if you could go through the **whole** tutorial yourself before doing any changes
- Keep the "Lego" - Experience :)
- No in depth explanations of Concepts (No distractions, User should find it very easy to work with Cerebral)
- It should work on all supported OS
- If you need to run it on Windows, and the packages are not already on npm, ping me (fops aka fopsdev) i have a running setup
- You can find all the stuff in a branch called "tutorial"
 
Thanks a lot and enjoy!
